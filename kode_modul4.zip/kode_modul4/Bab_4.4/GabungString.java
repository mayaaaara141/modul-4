public class GabungString {
    public static void main(String[] args) {
        String bagianPertama = "Halo, ";
        String bagianKedua = "Dunia!";
        
        String hasilGabungan = bagianPertama + bagianKedua;
        
        System.out.println(hasilGabungan);
    }
}