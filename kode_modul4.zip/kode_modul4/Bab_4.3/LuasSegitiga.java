import java.util.Scanner;

public class LuasSegitiga {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Masukkan alas segitiga: ");
        double alas = scanner.nextDouble();
        
        System.out.print("Masukkan tinggi segitiga: ");
        double tinggi = scanner.nextDouble();
        
        // Menggunakan 0.5 atau (1.0 / 2.0) agar pembagian tidak menjadi integer division (0)
        double luas = 0.5 * alas * tinggi;
        
        System.out.println("Luas segitiga adalah: " + luas);
    }
}