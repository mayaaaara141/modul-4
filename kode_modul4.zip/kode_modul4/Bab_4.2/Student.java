public class Student {

    String fName;
    String lName;
    int stuId;
    String stuStatus;

    public Student(String fName, String lName, int stuId, String stuStatus) {
        this.fName = fName;
        this.lName = lName;
        this.stuId = stuId;
        this.stuStatus = stuStatus;
    }
}