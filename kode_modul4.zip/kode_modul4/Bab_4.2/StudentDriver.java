public class StudentDriver {

    public static void main(String[] args) {

        Student student = new Student(
            "Lisa",
            "Palombo",
            123456789,
            "Active"
        );

        System.out.println("Student Name: "
                + student.fName + " " + student.lName);

        System.out.println("Student ID: "
                + student.stuId);

        System.out.println("Student Status: "
                + student.stuStatus);
    }
}